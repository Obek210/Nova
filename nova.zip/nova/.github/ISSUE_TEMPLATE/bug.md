---
name: Xato haqida xabar
about: Nimadir ishlamayapti
---
**Qurilma va Android versiyasi:**
**Nima qildingiz / qaysi buyruq:**
**Nima bo'ldi:**
**Kutilgan natija:**
